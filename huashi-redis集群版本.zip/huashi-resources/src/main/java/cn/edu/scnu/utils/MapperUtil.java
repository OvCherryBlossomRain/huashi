package cn.edu.scnu.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MapperUtil {
	public static final ObjectMapper MP=new ObjectMapper();
}
