package cn.edu.scnu.utils;

public class PrefixKey {
	public static final String PRODUCT_QUERY_PREFIX="product_query_";
	public static final String CUSTOMER_LOGINED_CHECK_PREFIX="customer_logined_";
	public static final String CUSTOMER_LOGIN_TICKET="EM_TICKET_";
	public static final String MOVIE_PREFIX="movie_";
}
