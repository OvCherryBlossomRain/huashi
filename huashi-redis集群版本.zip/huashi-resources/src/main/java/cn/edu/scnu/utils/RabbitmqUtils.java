package cn.edu.scnu.utils;

public class RabbitmqUtils {
	//定义多个常量值
	public static final String type="direct";
	public static final String EX="seckillDExchange";
	public static final String queue="seckillQueue";
	public static final String routingKey="seckillOne";
}
