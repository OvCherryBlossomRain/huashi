package cn.edu.scnu.pojo;

public class Actor {
	private Integer actorId;
	private String actorName;
	private String actorBirthDate;
	private String actorBirthPlace;
	private String actorInfo;
	private String actorImg;
	public Integer getActorId() {
		return actorId;
	}
	public void setActorId(Integer actorId) {
		this.actorId = actorId;
	}
	public String getActorName() {
		return actorName;
	}
	public void setActorName(String actorName) {
		this.actorName = actorName;
	}
	public String getActorBirthDate() {
		return actorBirthDate;
	}
	public void setActorBirthDate(String actorBirthDate) {
		this.actorBirthDate = actorBirthDate;
	}
	public String getActorBirthPlace() {
		return actorBirthPlace;
	}
	public void setActorBirthPlace(String actorBirthPlace) {
		this.actorBirthPlace = actorBirthPlace;
	}
	public String getActorInfo() {
		return actorInfo;
	}
	public void setActorInfo(String actorInfo) {
		this.actorInfo = actorInfo;
	}
	public String getActorImg() {
		return actorImg;
	}
	public void setActorImg(String actorImg) {
		this.actorImg = actorImg;
	}
	
}
